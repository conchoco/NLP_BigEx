
import nltk

from nltk.corpus import brown


brown_word_tags = []

for brown_sent in brown.tagged_sents():
    brown_word_tags.append(('START','START'))

    for words,tag in brown_sent:
        brown_word_tags.extend([(tag[:2], words)])

    brown_word_tags.append(("END", "END"))

cfd_tag_words = nltk.ConditionalFreqDist(brown_word_tags)
cpd_tag_words = nltk.ConditionalProbDist(cfd_tag_words, nltk.MLEProbDist)


print("The probability of an adjective (JJ) being 'smart' is", cpd_tag_words["JJ"].prob("smart"))
print("The probability of a verb (VB) being 'try' is", cpd_tag_words["VB"].prob("try"))


brown_tags = []
for tag, words in brown_word_tags:
    brown_tags.append(tag)
cfd_tags = nltk.ConditionalFreqDist(nltk.bigrams(brown_tags))

cpd_tags = nltk.ConditionalProbDist(cfd_tags, nltk.MLEProbDist)

print('The probability of DT occuring after NN is : ', cpd_tags["NN"].prob("DT"))
print('The probability of VB occuring after NN is : ', cpd_tags["NN"].prob("VB"))


prob_tagsequence = cpd_tags["START"].prob("PP") * cpd_tag_words["PP"].prob("I") * \
                   cpd_tags["PP"].prob("VB") * cpd_tag_words["VB"].prob("love") * \
                   cpd_tags["VB"].prob("NN") * cpd_tag_words["PP"].prob("food") * \
                   cpd_tags["NN"].prob("END")

print("The probability of sentence 'I love food' having the tag sequence 'START PP VB PP END' is : ", prob_tagsequence)




distinct_brown_tags = set(brown_tags)

sample_sentence = ["I", "love", "spicy", "food"]
len_sample_sentence = len(sample_sentence)



viterbi_tag = {}
viterbi_backpointer = {}

for tag in distinct_brown_tags:
    if tag == "START":
        continue
    viterbi_tag[tag] = cpd_tags["START"].prob(tag) * cpd_tag_words[tag].prob(sample_sentence[0])
    viterbi_backpointer[tag] = "START"


viterbi_main = []

backpointer_main = []


viterbi_main.append(viterbi_tag)
backpointer_main.append(viterbi_backpointer)

current_best = max(viterbi_tag.keys(), key=lambda tag: viterbi_tag[tag])


print("Word", "'" + sample_sentence[0] + "'", "current best two-tag sequence:", viterbi_backpointer[current_best], current_best)

for index in range(1,len_sample_sentence):
    curr_viterbi = {}
    curr_backpointer = {}
    prev_viterbi = viterbi_main[-1]

    for brown_tag in distinct_brown_tags:

        if brown_tag != "START":

            prev_best = max(prev_viterbi.keys(),
                                key=lambda prevtag: \
                                    prev_viterbi[prevtag] * cpd_tags[prevtag].prob(brown_tag) * cpd_tag_words[brown_tag].prob(
                                        sample_sentence[index]))

            curr_viterbi[brown_tag] = prev_viterbi[prev_best] * \
                                cpd_tags[prev_best].prob(brown_tag) * cpd_tag_words[brown_tag].prob(sample_sentence[index])
            curr_backpointer[brown_tag] = prev_best

    current_best = max(curr_viterbi.keys(), key=lambda tag: curr_viterbi[tag])
    print("Word", "'" + sample_sentence[index] + "'", "current best two-tag sequence:", curr_backpointer[current_best], current_best)


    viterbi_main.append(curr_viterbi)
    backpointer_main.append(curr_backpointer)

prev_viterbi = viterbi_main[-1]
prev_best = max(prev_viterbi.keys(),
                    key=lambda prev_tag: prev_viterbi[prev_tag] * cpd_tags[prev_tag].prob("END"))

prob_tag_sequence = prev_viterbi[prev_best] * cpd_tags[prev_best].prob("END")


best_tag_sequence = ["END", prev_best]
backpointer_main.reverse()

current_best_tag = prev_best
for backpointer in backpointer_main:
    best_tag_sequence.append(backpointer[current_best_tag])
    current_best_tag = backpointer[current_best_tag]


best_tag_sequence.reverse()

print ("The sentence given is :")
for word in sample_sentence:
    print (word,""),


print ("The best tag sequence using HMM for the given sentence is : ")


for best_tag in best_tag_sequence:
    print( best_tag, ""),

print ("The probability of the best tag sequence printed above is given by : ", prob_tag_sequence)